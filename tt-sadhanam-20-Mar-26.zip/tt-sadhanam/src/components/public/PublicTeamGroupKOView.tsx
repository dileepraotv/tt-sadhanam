'use client'

/**
 * PublicTeamGroupKOView
 *
 * Public-facing view for team_group_corbillon and team_group_swaythling formats.
 * Shows:
 *   Tab 1 — Groups: per-group standings table + fixture list
 *   Tab 2 — Knockout: KO bracket cards (round by round)
 *
 * Loads data client-side with real-time subscription (same pattern as
 * PublicTeamLeagueView) so live results update without a page reload.
 */

import { useState, useEffect, useRef } from 'react'
import { Layers, Trophy, ArrowRight, ChevronDown, ChevronRight } from 'lucide-react'
import { cn }                         from '@/lib/utils'
import type { Tournament }            from '@/lib/types'
import { createClient }               from '@/lib/supabase/client'
import { InlineLoader }               from '@/components/shared/GlobalLoader'
import { WinnerTrophy, matchStatusClasses } from '@/components/shared/MatchUI'

// ─── local types ─────────────────────────────────────────────────────────────

interface TeamRow {
  id:        string
  name:      string
  short_name: string | null
  color:     string | null
}

interface Submatch {
  id:           string
  match_order:  number
  label:        string
  player_a_name: string | null
  player_b_name: string | null
  match_id:     string | null
  scoring?: { player1_games: number; player2_games: number; status: string } | null
}

interface TeamMatchRow {
  id:             string
  team_a_id:      string
  team_b_id:      string
  round:          number
  round_name:     string | null
  status:         string
  team_a_score:   number
  team_b_score:   number
  winner_team_id: string | null
  group_id:       string | null
  team_a:         TeamRow | null
  team_b:         TeamRow | null
  submatches:     Submatch[]
}

interface GroupRow {
  id:           string
  group_number: number
  name:         string
  teamIds:      string[]
}

// ─── in-memory standings ─────────────────────────────────────────────────────

function computeStandings(groupId: string, teamIds: string[], matches: TeamMatchRow[]) {
  const map = new Map(teamIds.map(id => [id, { teamId: id, mW: 0, mL: 0, smW: 0, smL: 0, gd: 0 }]))
  for (const m of matches) {
    if (m.group_id !== groupId || m.status !== 'complete') continue
    const sA = map.get(m.team_a_id)
    const sB = map.get(m.team_b_id)
    if (m.winner_team_id === m.team_a_id) { sA && sA.mW++; sB && sB.mL++ }
    else if (m.winner_team_id === m.team_b_id) { sB && sB.mW++; sA && sA.mL++ }
    for (const sm of m.submatches) {
      const sc = sm.scoring
      if (!sc || sc.status !== 'complete') continue
      const aWon = sc.player1_games > sc.player2_games
      if (sA) { sA.smW += aWon ? 1 : 0; sA.smL += aWon ? 0 : 1; sA.gd += sc.player1_games - sc.player2_games }
      if (sB) { sB.smW += aWon ? 0 : 1; sB.smL += aWon ? 1 : 0; sB.gd += sc.player2_games - sc.player1_games }
    }
  }
  return [...map.values()].sort((a, b) => b.mW - a.mW || b.smW - a.smW || b.gd - a.gd)
}

// ─────────────────────────────────────────────────────────────────────────────
// Main component
// ─────────────────────────────────────────────────────────────────────────────

export function PublicTeamGroupKOView({ tournament }: { tournament: Tournament }) {
  const supabase = createClient()

  const [teams,       setTeams]       = useState<TeamRow[]>([])
  const [teamMatches, setTeamMatches] = useState<TeamMatchRow[]>([])
  const [groups,      setGroups]      = useState<GroupRow[]>([])
  const [advanceCount, setAdvanceCount] = useState(1)
  const [loading,     setLoading]     = useState(true)
  const [tab,         setTab]         = useState<'groups' | 'knockout'>('groups')
  const [expandedGroup, setExpandedGroup] = useState<string | null>(null)
  const [activeKORound, setActiveKORound] = useState<number | null>(null)

  const loadData = async () => {
    // 3 fully-parallel queries — rr_groups embedded in stage select (no serial 4th trip)
    const [teamsRes, stageRes, matchesRes] = await Promise.all([
      supabase.from('teams').select('id, name, short_name, color')
        .eq('tournament_id', tournament.id).order('created_at'),
      supabase.from('stages')
        .select('id, config, rr_groups(id, group_number, name, team_rr_group_members(team_id))')
        .eq('tournament_id', tournament.id).eq('stage_number', 1).maybeSingle(),
      supabase.from('team_matches')
        .select(`
          id, team_a_id, team_b_id, round, round_name, status,
          team_a_score, team_b_score, winner_team_id, group_id,
          team_a:team_a_id(id,name,short_name,color),
          team_b:team_b_id(id,name,short_name,color),
          submatches:team_match_submatches(
            id, match_order, label,
            player_a_name, player_b_name, match_id,
            scoring:match_id(player1_games, player2_games, status)
          )
        `)
        .eq('tournament_id', tournament.id)
        .order('round'),
    ])

    setTeams(teamsRes.data ?? [])
    setTeamMatches((matchesRes.data ?? []).map(tm => ({
      ...tm,
      submatches: ((tm as unknown as { submatches?: Submatch[] }).submatches ?? [])
        .sort((a, b) => a.match_order - b.match_order),
    })) as unknown as TeamMatchRow[])

    const stageData = stageRes.data
    if (stageData) {
      setAdvanceCount((stageData.config as { advanceCount?: number }).advanceCount ?? 1)
      // rr_groups already loaded via join — no extra round-trip needed
      const groupRows = (stageData as unknown as {
        rr_groups: Array<{ id: string; group_number: number; name: string; team_rr_group_members: { team_id: string }[] }>
      }).rr_groups ?? []
      setGroups(groupRows.map(g => ({
        id:           g.id,
        group_number: g.group_number,
        name:         g.name,
        teamIds:      (g.team_rr_group_members ?? []).map(m => m.team_id),
      })))
    }

    setLoading(false)
  }

  useEffect(() => { loadData() }, [tournament.id])

  // Debounce ref: collapse rapid Realtime bursts into a single reload
  const reloadTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const scheduledReload = () => {
    if (reloadTimer.current) clearTimeout(reloadTimer.current)
    reloadTimer.current = setTimeout(() => { loadData().catch(console.error) }, 300)
  }

  useEffect(() => {
    const channel = supabase
      .channel(`pub-team-group-${tournament.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'team_matches', filter: `tournament_id=eq.${tournament.id}` }, scheduledReload)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'team_match_submatches' }, scheduledReload)
      .subscribe()
    return () => {
      if (reloadTimer.current) clearTimeout(reloadTimer.current)
      supabase.removeChannel(channel)
    }
  }, [tournament.id])

  if (loading) return <InlineLoader label="Loading…" />

  const rrMatches = teamMatches.filter(m => m.group_id != null)
  const koMatches = teamMatches.filter(m => m.group_id == null && m.round >= 900)
  const teamById  = new Map(teams.map(t => [t.id, t]))

  const hasKO     = koMatches.length > 0

  // Auto-switch to knockout tab when KO exists and all RR done
  const allRRDone = rrMatches.length > 0 && rrMatches.every(m => m.status === 'complete')

  return (
    <div className="flex flex-col">
      {/* Tab bar — white surface so tabs are visible on orange page background */}
      <div className="border-b border-border/60 flex gap-1 px-4 sm:px-6">
        {([
          { key: 'groups',   label: 'Groups',   icon: <Layers className="h-3.5 w-3.5" /> },
          { key: 'knockout', label: 'Knockout',  icon: <Trophy className="h-3.5 w-3.5" />, disabled: !hasKO },
        ] as const).map(t => (
          <button
            key={t.key}
            disabled={'disabled' in t && t.disabled}
            onClick={() => setTab(t.key)}
            className={cn(
              'flex items-center gap-1.5 px-3 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px',
              tab === t.key
                ? 'border-orange-500 text-orange-600 dark:text-orange-400 font-semibold'
                : 'border-transparent text-foreground/80 hover:text-foreground disabled:opacity-40 disabled:cursor-not-allowed',
            )}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </div>

      <div className="page-content flex flex-col gap-4">
        {/* ── Groups tab ── */}
        {tab === 'groups' && (
          <div className="flex flex-col gap-4">
            {groups.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-8">Group stage not yet started.</p>
            )}

            {groups.map(group => {
              const standings   = computeStandings(group.id, group.teamIds, teamMatches)
              const groupMats   = rrMatches.filter(m => m.group_id === group.id)
              const isExpanded  = expandedGroup === group.id
              const allDone     = groupMats.length > 0 && groupMats.every(m => m.status === 'complete')
              const hasStarted  = standings.some(r => r.mW + r.mL > 0)

              return (
                <div key={group.id} className={cn(
                  'rounded-xl border overflow-hidden',
                  allDone ? 'border-border/40 bg-[#BEBEBE]/60 dark:bg-[#5a5a5a]/40' : 'border-border bg-card',
                )}>
                  {/* Group header — always visible */}
                  <div className="px-4 pt-3 pb-0">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-foreground">{group.name}</span>
                        {groupMats.some(m => m.status === 'live') && <span className="live-dot" />}
                        {allDone && <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">✓ Complete</span>}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {groupMats.filter(m => m.status === 'complete').length}/{groupMats.length} done
                      </span>
                    </div>

                    {/* Standings — always visible */}
                    <div className="flex flex-col gap-0.5 mb-2">
                      {standings.map((row, idx) => {
                        const t   = teamById.get(row.teamId) as TeamRow | undefined
                        const adv = idx < advanceCount
                        return (
                          <div key={row.teamId} className={cn(
                            'flex items-center gap-2 px-2 py-1.5 rounded-lg text-sm',
                            adv && hasStarted ? 'bg-emerald-50/60 dark:bg-emerald-950/20' : '',
                          )}>
                            <span className={cn(
                              'text-xs font-bold w-4 text-center shrink-0',
                              adv && hasStarted ? 'text-emerald-600 dark:text-emerald-400' : 'text-muted-foreground',
                            )}>{idx + 1}</span>
                            <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ background: t?.color ?? '#888' }} />
                            <span className={cn(
                              'flex-1 min-w-0 truncate',
                              idx === 0 && hasStarted ? 'font-semibold text-foreground' : 'text-foreground',
                            )}>{t?.name ?? '?'}</span>
                            <div className="flex items-center gap-3 shrink-0">
                              <span className="text-xs font-mono tabular-nums" title="Matches Won-Lost">
                                <span className={cn('font-bold', row.mW > 0 ? 'text-foreground' : 'text-muted-foreground/40')}>{row.mW}</span>
                                <span className="text-muted-foreground/40">-{row.mL}</span>
                              </span>
                              <span className="text-xs font-mono tabular-nums text-muted-foreground" title="Rubbers Won-Lost">
                                {row.smW}-{row.smL ?? 0}
                              </span>
                            </div>
                            {adv && hasStarted && <ArrowRight className="h-3 w-3 text-emerald-500 shrink-0" />}
                          </div>
                        )
                      })}
                    </div>
                    {hasStarted && (
                      <p className="text-[10px] text-muted-foreground mb-2 px-1">
                        Top {advanceCount} advance · W-L = Matches · Rubbers W-L
                      </p>
                    )}
                  </div>

                  {/* Fixtures toggle */}
                  <button
                    className="w-full flex items-center justify-between px-4 py-2 border-t border-border/40 bg-muted/20 hover:bg-muted/30 transition-colors text-left"
                    onClick={() => setExpandedGroup(isExpanded ? null : group.id)}
                  >
                    <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                      {isExpanded ? 'Hide Fixtures' : 'Show Fixtures'}
                    </span>
                    {isExpanded
                      ? <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                      : <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />}
                  </button>

                  {isExpanded && (
                    <div className="px-4 pb-4 flex flex-col gap-4 pt-3">
                      {/* Fixtures */}
                      {groupMats.length > 0 && (
                        <div className="flex flex-col gap-2">
                          {groupMats.map(m => (
                            <PublicFixtureRow key={m.id} match={m} />
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )
            })}

            {/* Prompt to switch to KO */}
            {hasKO && (
              <div className="rounded-lg border border-emerald-200 dark:border-emerald-800 bg-emerald-50/50 dark:bg-emerald-950/20 px-4 py-3 flex items-center justify-between gap-3">
                <span className="text-sm font-medium text-emerald-700 dark:text-emerald-300">
                  Knockout bracket is live!
                </span>
                <button
                  onClick={() => setTab('knockout')}
                  className="text-sm font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
                >
                  View Bracket <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* ── Knockout tab ── */}
        {tab === 'knockout' && (
          <div className="flex flex-col gap-4">
            {koMatches.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                Knockout bracket not yet generated.
              </p>
            ) : (() => {
              const koRoundMap = new Map<number, TeamMatchRow[]>()
              for (const m of koMatches) {
                const arr = koRoundMap.get(m.round) ?? []
                arr.push(m)
                koRoundMap.set(m.round, arr)
              }
              const rounds = [...koRoundMap.entries()].sort((a, b) => a[0] - b[0])
              // Auto-select: live round > first pending > last round
              const liveR = rounds.find(([, ms]) => ms.some(m => m.status === 'live'))
              const pendR = rounds.find(([, ms]) => ms.some(m => m.status === 'pending'))
              const defR  = liveR?.[0] ?? pendR?.[0] ?? rounds[rounds.length - 1]?.[0] ?? null
              const display = activeKORound ?? defR
              return (
                <div className="bg-card rounded-xl border border-border overflow-hidden">
                  {/* Orange tab bar */}
                  <div
                    className="flex items-end gap-1 overflow-x-auto scrollbar-hide border-b-2 px-2 pt-2"
                    style={{ borderColor: '#F06321' }}
                  >
                    {rounds.map(([roundN, ms]) => {
                      const isActive = display === roundN
                      const hasLive  = ms.some(m => m.status === 'live')
                      const allDone  = ms.every(m => m.status === 'complete')
                      const label    = ms[0]?.round_name ?? `Round ${roundN - 899}`
                      return (
                        <button
                          key={roundN}
                          onClick={() => setActiveKORound(roundN)}
                          style={isActive
                            ? { background: '#F06321', color: '#fff', border: '2px solid #F06321', borderBottom: 'none' }
                            : undefined}
                          className={cn(
                            'shrink-0 px-4 pt-2 pb-2 text-sm font-bold transition-all rounded-t-lg whitespace-nowrap flex items-center gap-1.5',
                            !isActive && 'text-muted-foreground hover:text-foreground hover:bg-muted/60',
                          )}
                        >
                          {label}
                          {hasLive && (
                            <span className="inline-flex h-4 w-4 items-center justify-center rounded-full text-[10px] font-bold"
                              style={{ background: isActive ? 'rgba(255,255,255,0.35)' : '#F06321', color: '#fff' }}>
                              ●
                            </span>
                          )}
                          {allDone && !hasLive && (
                            <span className={cn('text-[10px] font-bold', isActive ? 'text-white/80' : 'text-emerald-500')}>✓</span>
                          )}
                        </button>
                      )
                    })}
                  </div>
                  {/* Active round matches */}
                  {display != null && (() => {
                    const ms = koRoundMap.get(display) ?? []
                    return (
                      <div className="p-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                        {ms.map(m => <PublicKOCard key={m.id} match={m} />)}
                      </div>
                    )
                  })()}
                </div>
              )
            })()}
          </div>
        )}
      </div>
    </div>
  )
}

// ─── PublicFixtureRow ─────────────────────────────────────────────────────────
// Groups tab: shows team match with standings-style winner/loser styling + rubber details

function PublicFixtureRow({ match }: { match: TeamMatchRow }) {
  const [expanded, setExpanded] = useState(false)
  const isComplete = match.status === 'complete'
  const isLive     = match.status === 'live'
  const aWon       = isComplete && match.winner_team_id === match.team_a_id
  const bWon       = isComplete && match.winner_team_id === match.team_b_id
  const done       = match.submatches.filter(s => s.scoring?.status === 'complete').length
  const total      = match.submatches.length

  const WINNER_ROW = 'border border-blue-900/35 bg-blue-950/5 dark:bg-blue-900/10 dark:border-blue-700/40 rounded'

  return (
    <div className={cn('rounded-lg border overflow-hidden',
      isLive     ? 'border-orange-400/70 bg-orange-50/50 dark:bg-orange-950/15' :
      isComplete ? 'border-border/40 bg-[#BEBEBE]/60 dark:bg-[#5a5a5a]/40' :
                   'border-border bg-card',
    )}>
      <button
        className="w-full px-3 pt-2.5 pb-2 text-left hover:bg-muted/10 transition-colors"
        onClick={() => setExpanded(e => !e)}
      >
        {/* Team A row */}
        <div className={cn('flex items-center gap-1.5 px-1 py-0.5', aWon && WINNER_ROW)}>
          <WinnerTrophy show={aWon} size="sm" />
          <span className="w-2 h-2 rounded-full shrink-0" style={{ background: (match.team_a as any)?.color ?? '#888' }} />
          <span className={cn('text-sm flex-1 min-w-0 truncate',
            aWon ? 'font-bold text-foreground' : bWon ? 'font-normal text-muted-foreground' : 'font-semibold text-foreground')}>
            {match.team_a?.name ?? '—'}
          </span>
          <span className={cn('font-mono font-bold text-sm tabular-nums shrink-0',
            aWon ? 'text-foreground' : bWon ? 'text-muted-foreground/50' : 'text-muted-foreground/70')}>
            {match.team_a_score}
          </span>
          <div className="flex items-center gap-1.5 shrink-0 ml-1">
            {isLive && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-orange-100 dark:bg-orange-900/40 text-orange-600">LIVE</span>}
            <span className="text-xs text-muted-foreground">{done}/{total}</span>
            <ChevronDown className={cn('h-3.5 w-3.5 text-muted-foreground transition-transform', expanded && 'rotate-180')} />
          </div>
        </div>

        {/* Divider */}
        <div className="border-b border-border/20 my-1 mx-1" />

        {/* Team B row */}
        <div className={cn('flex items-center gap-1.5 px-1 py-0.5', bWon && WINNER_ROW)}>
          <WinnerTrophy show={bWon} size="sm" />
          <span className="w-2 h-2 rounded-full shrink-0" style={{ background: (match.team_b as any)?.color ?? '#888' }} />
          <span className={cn('text-sm flex-1 min-w-0 truncate',
            bWon ? 'font-bold text-foreground' : aWon ? 'font-normal text-muted-foreground' : 'font-semibold text-foreground')}>
            {match.team_b?.name ?? '—'}
          </span>
          <span className={cn('font-mono font-bold text-sm tabular-nums shrink-0',
            bWon ? 'text-foreground' : aWon ? 'text-muted-foreground/50' : 'text-muted-foreground/70')}>
            {match.team_b_score}
          </span>
          <span className="w-16 shrink-0" />
        </div>
      </button>

      {/* Expanded rubber details */}
      {expanded && (
        <div className="border-t border-border/40 divide-y divide-border/30">
          <div className="px-3 py-1.5 grid grid-cols-[1fr_auto_1fr] gap-2 bg-muted/30">
            <span className="text-[10px] font-bold text-muted-foreground uppercase">{match.team_a?.name ?? 'Team A'}</span>
            <span className="text-[10px] text-muted-foreground" />
            <span className="text-[10px] font-bold text-muted-foreground uppercase text-right">{match.team_b?.name ?? 'Team B'}</span>
          </div>
          {match.submatches.map((sm, idx) => {
            const sc    = sm.scoring
            const smDone = sc?.status === 'complete'
            const smLive = sc?.status === 'live'
            const p1g   = sc?.player1_games ?? 0
            const p2g   = sc?.player2_games ?? 0
            const smAWon = smDone && p1g > p2g
            const smBWon = smDone && p2g > p1g
            return (
              <div key={sm.id} className={cn('px-3 py-2 grid grid-cols-[1fr_auto_1fr] gap-2 items-center text-xs',
                smLive && 'bg-orange-50/30 dark:bg-orange-950/10',
              )}>
                <div className="flex items-center gap-1 min-w-0">
                  <span className="text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center shrink-0 bg-muted text-muted-foreground">{idx + 1}</span>
                  <span className={cn('truncate', smAWon ? 'font-semibold text-foreground' : smBWon ? 'text-muted-foreground' : '')}>{sm.player_a_name ?? '—'}</span>
                </div>
                <div className="flex items-center gap-1 shrink-0 justify-center">
                  {smDone ? (
                    <span className="font-mono font-bold tabular-nums text-xs">
                      <span className={smAWon ? 'text-foreground' : 'text-muted-foreground/50'}>{p1g}</span>
                      <span className="text-muted-foreground mx-0.5">–</span>
                      <span className={smBWon ? 'text-foreground' : 'text-muted-foreground/50'}>{p2g}</span>
                    </span>
                  ) : smLive ? (
                    <span className="flex items-center gap-1 text-orange-500">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
                      <span className="font-mono text-xs">{p1g}–{p2g}</span>
                    </span>
                  ) : (
                    <span className="text-[10px] text-muted-foreground/40">vs</span>
                  )}
                </div>
                <div className="flex items-center gap-1 min-w-0 justify-end">
                  <span className={cn('truncate text-right', smBWon ? 'font-semibold text-foreground' : smAWon ? 'text-muted-foreground' : '')}>{sm.player_b_name ?? '—'}</span>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

// ─── PublicKOCard ─────────────────────────────────────────────────────────────

function PublicKOCard({ match }: { match: TeamMatchRow }) {
  const [expanded, setExpanded] = useState(false)
  const isComplete = match.status === 'complete'
  const isLive     = match.status === 'live'
  const aWon       = isComplete && match.winner_team_id === match.team_a_id
  const bWon       = isComplete && match.winner_team_id === match.team_b_id
  const done       = match.submatches.filter(s => s.scoring?.status === 'complete').length

  const WINNER_ROW = 'border border-blue-900/35 bg-blue-950/5 dark:bg-blue-900/10 dark:border-blue-700/40 rounded'

  return (
    <div className={cn('rounded-xl border overflow-hidden',
      isLive     ? 'border-orange-400/70 bg-orange-50/50 dark:bg-orange-950/15 shadow-sm' :
      isComplete ? 'border-border/40 bg-[#BEBEBE]/60 dark:bg-[#5a5a5a]/40' :
                   'border-border bg-card',
    )}>
      <button
        className="w-full px-3 py-2.5 flex flex-col gap-1.5 text-left hover:bg-muted/10 transition-colors"
        onClick={() => setExpanded(e => !e)}
      >
        {/* Team A row */}
        <div className={cn('flex items-center gap-2 px-1 py-0.5', aWon && WINNER_ROW)}>
          <WinnerTrophy show={aWon} size="sm" />
          <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: (match.team_a as TeamRow | null)?.color ?? '#888' }} />
          <span className={cn('text-sm flex-1 truncate',
            aWon ? 'font-bold text-foreground' : bWon ? 'font-normal text-muted-foreground' : 'font-semibold text-foreground')}>
            {match.team_a?.name ?? 'TBD'}
          </span>
          <span className={cn('text-sm font-bold font-mono tabular-nums shrink-0',
            aWon ? 'text-foreground' : bWon ? 'text-muted-foreground/50' : 'text-muted-foreground/70')}>
            {match.team_a_score}
          </span>
        </div>

        <div className="border-t border-border/30 mx-1" />

        {/* Team B row */}
        <div className={cn('flex items-center gap-2 px-1 py-0.5', bWon && WINNER_ROW)}>
          <WinnerTrophy show={bWon} size="sm" />
          <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: (match.team_b as TeamRow | null)?.color ?? '#888' }} />
          <span className={cn('text-sm flex-1 truncate',
            bWon ? 'font-bold text-foreground' : aWon ? 'font-normal text-muted-foreground' : 'font-semibold text-foreground')}>
            {match.team_b?.name ?? 'TBD'}
          </span>
          <span className={cn('text-sm font-bold font-mono tabular-nums shrink-0',
            bWon ? 'text-foreground' : aWon ? 'text-muted-foreground/50' : 'text-muted-foreground/70')}>
            {match.team_b_score}
          </span>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-border/20 pt-1.5 mx-1">
          <div className="flex items-center gap-2">
            {isLive && <span className="text-xs font-semibold px-1.5 py-0.5 rounded-full bg-orange-100 dark:bg-orange-900/40 text-orange-600 dark:text-orange-400">LIVE</span>}
            {isComplete && <span className="text-xs text-muted-foreground font-medium">Done</span>}
            {!isLive && !isComplete && <span className="text-xs text-muted-foreground">Upcoming</span>}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">{done}/{match.submatches.length}</span>
            <ChevronDown className={cn('h-3.5 w-3.5 text-muted-foreground transition-transform', expanded && 'rotate-180')} />
          </div>
        </div>
      </button>

      {/* Expanded rubber details */}
      {expanded && match.submatches.length > 0 && (
        <div className="border-t border-border/40 divide-y divide-border/30">
          {match.submatches.map((sm, idx) => {
            const sc     = sm.scoring
            const smDone = sc?.status === 'complete'
            const smLive = sc?.status === 'live'
            const p1g    = sc?.player1_games ?? 0
            const p2g    = sc?.player2_games ?? 0
            const smAWon = smDone && p1g > p2g
            const smBWon = smDone && p2g > p1g
            return (
              <div key={sm.id} className={cn('px-3 py-2 text-xs', smLive && 'bg-orange-50/30 dark:bg-orange-950/10')}>
                <div className="flex items-center gap-1 mb-0.5">
                  <span className="text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center shrink-0 bg-muted text-muted-foreground">{idx + 1}</span>
                  <span className="text-muted-foreground">{sm.label}</span>
                  {smDone && (
                    <span className="ml-auto font-mono font-bold tabular-nums">
                      <span className={smAWon ? 'text-foreground' : 'text-muted-foreground/50'}>{p1g}</span>
                      <span className="text-muted-foreground mx-0.5">–</span>
                      <span className={smBWon ? 'text-foreground' : 'text-muted-foreground/50'}>{p2g}</span>
                    </span>
                  )}
                  {smLive && (
                    <span className="ml-auto flex items-center gap-1 text-orange-500 font-mono font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse shrink-0" />
                      {p1g}–{p2g}
                    </span>
                  )}
                  {!smDone && !smLive && <span className="ml-auto text-muted-foreground/40">vs</span>}
                </div>
                <div className="grid grid-cols-[1fr_auto_1fr] gap-1 ml-5">
                  <span className={cn('truncate', smAWon ? 'font-semibold text-foreground' : 'text-muted-foreground')}>{sm.player_a_name ?? '—'}</span>
                  <span className="text-muted-foreground/30 text-[10px]">vs</span>
                  <span className={cn('truncate text-right', smBWon ? 'font-semibold text-foreground' : 'text-muted-foreground')}>{sm.player_b_name ?? '—'}</span>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
